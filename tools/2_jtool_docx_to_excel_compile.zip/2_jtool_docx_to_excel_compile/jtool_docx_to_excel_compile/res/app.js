const fileInput = document.getElementById("fileInput");
const scanBtn = document.getElementById("scanBtn");
const exportBtn = document.getElementById("exportBtn");
const tagList = document.getElementById("tagList");
const log = document.getElementById("log");

let parsedDocs = [];
let allTags = {};

fileInput.addEventListener("change", () => {
    let docx = 0, pdf = 0, img = 0, other = 0;

    [...fileInput.files].forEach(f => {
        if (f.name.toLowerCase().endsWith(".docx")) docx++;
        else if (f.name.toLowerCase().endsWith(".pdf")) pdf++;
        else if (f.type.startsWith("image/")) img++;
        else other++;
    });

    docxCount.textContent = `DOCX: ${docx}`;
    pdfCount.textContent = `PDF: ${pdf}`;
    imgCount.textContent = `Images: ${img}`;
    otherCount.textContent = `Others: ${other}`;
});

scanBtn.addEventListener("click", async () => {
    parsedDocs = [];
    allTags = {};
    tagList.innerHTML = "";
    log.textContent = "Scanning...\n";

    for (let file of fileInput.files) {
        if (!file.name.toLowerCase().endsWith(".docx")) continue;

        try {
            const buffer = await file.arrayBuffer();
            const zip = await JSZip.loadAsync(buffer);
            const xml = await zip.file("word/document.xml").async("string");

            const dom = new DOMParser().parseFromString(xml, "text/xml");
            const sdts = dom.getElementsByTagName("w:sdt");

            let data = {};

            for (let sdt of sdts) {
                const tagEl = sdt.getElementsByTagName("w:tag")[0];
                if (!tagEl) continue;

                const tag = tagEl.getAttribute("w:val");
                const title =
                    sdt.getElementsByTagName("w:alias")[0]?.getAttribute("w:val") || tag;

                const texts = [...sdt.getElementsByTagName("w:t")]
                    .map(t => t.textContent)
                    .join(" ")
                    .trim();

                data[tag] = { title, value: texts };
                allTags[tag] = title;
            }

            parsedDocs.push({
                file: file.webkitRelativePath || file.name,
                data
            });

            log.textContent += `✔ ${file.name}\n`;
        } catch (e) {
            log.textContent += `✖ ${file.name}: ${e.message}\n`;
        }
    }

    renderTagList();
    log.textContent += "Scan finished.\n";
});

function renderTagList() {
    tagList.innerHTML = "";
    Object.entries(allTags).forEach(([tag, title]) => {
        const label = document.createElement("label");
        label.innerHTML = `
            <input type="checkbox" value="${tag}" checked>
            ${title} <small>(${tag})</small>
        `;
        tagList.appendChild(label);
    });
}

exportBtn.addEventListener("click", () => {
    const selected = [...tagList.querySelectorAll("input:checked")]
        .map(i => i.value);

    if (!selected.length) {
        alert("Select at least one tag");
        return;
    }

    // Auto-ignore tags empty in ALL documents
    const finalTags = selected.filter(tag =>
        parsedDocs.some(doc => doc.data[tag]?.value?.trim())
    );

    if (!finalTags.length) {
        alert("All selected fields are empty.");
        return;
    }

    let rows = [];
    rows.push(["File Name", ...finalTags.map(t => allTags[t])]);

    parsedDocs.forEach(doc => {
        let row = [doc.file];
        finalTags.forEach(t => row.push(doc.data[t]?.value || ""));
        rows.push(row);
    });

    const ws = XLSX.utils.aoa_to_sheet(rows);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Form Data");

    XLSX.writeFile(wb, "docx_form_data.xlsx");
});
