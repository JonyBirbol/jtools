jtool_docx_to_excel_compile
=> What is the purpose of this tool?

*** Problem

In many cases, organizations receive a large number of completed MS Word forms (often 500 or more .docx files) from users via email. Each form contains structured data entered by the user.
Manually compiling this information into a single MS Excel file requires opening each Word document and copying the data field by field into Excel. 
Performing this process for hundreds of files is extremely time-consuming, repetitive, and error-prone.

*** Solution

This tool automates the process by extracting data directly from multiple MS Word (.docx) files and consolidating it into a single MS Excel file. 
With just a few clicks, all form data can be collected accurately and efficiently—eliminating manual copy-and-paste work and significantly reducing processing time.

*** Prerequisite

All user-input fields in the MS Word form must be created using “Content Controls” and provide the Title and Tag from "Properties" menu (from the > Developer Mode).
Content controls should be preserved and not deleted by users when filling out the form.